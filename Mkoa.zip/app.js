/**
 * 导入 root路径 Mkoa的路径
 */
require(__dirname+'/Mkoa/index')(__dirname,__dirname+'/Mkoa/');